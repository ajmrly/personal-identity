<?php

kirbytext::$tags['a'] = array();