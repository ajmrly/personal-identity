<div class="modal-content">
  <div class="form">
    <div class="text">
      <strong>Logins are currently blocked</strong><br>
      <a href="">Try again</a> or contact your administrator.
    </div>
  </div>
</div> 

<script>

$(function() {
  $('.modal-content').center(48);
});

</script>